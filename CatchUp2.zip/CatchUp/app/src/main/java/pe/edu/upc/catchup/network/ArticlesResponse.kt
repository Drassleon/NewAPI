package pe.edu.upc.catchup.network

import pe.edu.upc.catchup.models.Article

class ArticlesResponse{
    val status: String= ""
    val code: String?= null
    val message: String?= null
    val totalResults:Int?=0
    val articles:ArrayList<Article>?=null
}